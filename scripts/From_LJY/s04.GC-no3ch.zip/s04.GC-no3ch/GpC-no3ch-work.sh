for i in `cat /datc/lijingyun/project/guofan/s01.trim/sample_list`;do sh GpC-no3ch.sh $i;done

