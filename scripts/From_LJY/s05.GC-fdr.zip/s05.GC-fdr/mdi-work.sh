for i in `cat /datc/lijingyun/project/guofan/s01.trim/sample_list`;do sh s06.mdi.sh $i;done

